    
    //
//  LeftDrawerView.swift
//  LeftAndRightDrawerDemoApp
//
//  Created by Kumar on 20/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

import UIKit

class LeftDrawerView: UIView {

    @IBOutlet var leftTableView: UITableView!
    @IBAction func hideLeftDrawer(sender: AnyObject) {
        
        self.removeDrawerFromUIViewController();
    }
    
      override func drawRect(rect: CGRect)
      {
           let screen:CGRect=UIScreen.mainScreen().bounds;
            self.frame=screen;
        
    }
    
    func removeDrawerFromUIViewController()->Void
    {
       
        UIView.animateWithDuration(0.5, delay: 0.0, options: UIViewAnimationOptions.TransitionNone, animations: {
            let screenRect:CGRect=UIScreen.mainScreen().bounds;
            var napkinButtomFrane:CGRect=screenRect;
            napkinButtomFrane.origin.x = -(self.frame.size.width);
            self.frame=napkinButtomFrane;
            }) { (finished:Bool) -> Void in
            self.removeFromSuperview();
        }
        
    }
    

}
