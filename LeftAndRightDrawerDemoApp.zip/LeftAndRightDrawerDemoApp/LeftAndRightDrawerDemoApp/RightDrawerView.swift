//
//  RightDrawerView.swift
//  LeftAndRightDrawerDemoApp
//
//  Created by Kumar on 20/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

import UIKit

class RightDrawerView: UIView {

    @IBOutlet var rightTableView: UITableView!
   
    override func drawRect(rect: CGRect)
    {
        let screen:CGRect=UIScreen.mainScreen().bounds;
        self.frame=screen;
    }

    @IBAction func hideRightDrawer(sender: AnyObject)
    {
        self.hideRightDrawerMethod();
    }
    func hideRightDrawerMethod()->Void
    {
        
        UIView.animateWithDuration(0.5, delay: 0.0, options: UIViewAnimationOptions.TransitionNone, animations: {
            
            let screenRect:CGRect=UIScreen.mainScreen().bounds;
            var napkinButton:CGRect=screenRect;
            napkinButton.origin.x = +(self.frame.size.width);
            self.frame=napkinButton;
            }) { (finished:Bool) -> Void in
            self.removeFromSuperview();
        }
    }

}
