//
//  ViewController.swift
//  LeftAndRightDrawerDemoApp
//
//  Created by Kumar on 19/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

import UIKit

class ViewController: UIViewController,HeaderViewDelegates
{

    override func viewDidLoad() {
        super.viewDidLoad()
      
        self.headerView();
        
    }

    
    func headerView()->Void
    {
        var navigationBar:HeaderView=(NSBundle.mainBundle().loadNibNamed("HeaderView", owner: self, options: nil)[0]as?HeaderView)!;
        navigationBar.delegate=self;
        
        self.view.addSubview(navigationBar as UIView);
        
    }
    func leftDrawerMenu() {
        
        self.leftDrawer();
        
    }
    
    func leftDrawer()->Void
    {
        var left:LeftDrawerView=(NSBundle.mainBundle().loadNibNamed("LeftDrawerView", owner: self, options: nil)[0]as?LeftDrawerView)!;
        
        let transition = CATransition();
        transition.duration=0.5;
        transition.type=kCATransitionPush;
        transition.subtype=kCATransitionFromLeft;
        left.layer.addAnimation(transition, forKey: nil);
        self.view.addSubview(left as UIView);
        
    }
    
    func rightDrawerMenu()
    {
        self.rightDrawe();
    }

    func rightDrawe()->Void
    {
        var right:RightDrawerView=(NSBundle.mainBundle().loadNibNamed("RightDrawerView", owner: self, options: nil)[0]as?RightDrawerView)!;
        
        let transition=CATransition();
        transition.duration=0.5;
        transition.type=kCATransitionPush;
        transition.subtype=kCATransitionFromRight;
        right.layer.addAnimation(transition, forKey: nil);
        
        self.view.addSubview(right as UIView);
        
    }
    
}

