//
//  HeaderView.swift
//  LeftAndRightDrawerDemoApp
//
//  Created by Kumar on 19/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

import UIKit
protocol HeaderViewDelegates
{
    func leftDrawerMenu()->Void;
    func rightDrawerMenu()->Void;
    
}
class HeaderView: UIView {
    var delegate:HeaderViewDelegates?;
    
    @IBAction func leftdrawerButton(sender: AnyObject) {
        
        self.delegate?.leftDrawerMenu();
    }
    
    @IBAction func rightDrawerButton(sender: AnyObject) {
        self.delegate?.rightDrawerMenu();
    }
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
